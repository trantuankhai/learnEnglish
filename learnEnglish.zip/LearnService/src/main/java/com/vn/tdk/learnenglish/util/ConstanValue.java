package com.vn.tdk.learnenglish.util;

public interface ConstanValue {
	public static final String NULL_VALUE = "";
}
