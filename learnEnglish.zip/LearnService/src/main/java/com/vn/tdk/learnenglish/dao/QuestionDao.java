package com.vn.tdk.learnenglish.dao;

import com.vn.tdk.learnenglish.entity.Question;

public interface QuestionDao extends TempleteDao<Question> {

}
