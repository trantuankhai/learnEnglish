package com.vn.tdk.learnenglish.sevices;

import com.vn.tdk.learnenglish.entity.BasicGrammar;

public interface BasicGrammerService extends services<BasicGrammar> {

}
