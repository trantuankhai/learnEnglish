package com.vn.tdk.learnenglish.dao;

import com.vn.tdk.learnenglish.entity.FeedBack;

public interface FeedBackDao extends TempleteDao<FeedBack> {

}
