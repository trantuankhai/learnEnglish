package com.vn.tdk.learnenglish.dao;

import com.vn.tdk.learnenglish.entity.Vocabulary;

public interface VocabularyDao extends TempleteDao<Vocabulary> {

}
