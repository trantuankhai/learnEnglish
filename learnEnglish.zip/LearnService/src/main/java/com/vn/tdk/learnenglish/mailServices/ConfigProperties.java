package com.vn.tdk.learnenglish.mailServices;

public class ConfigProperties {
	
}
