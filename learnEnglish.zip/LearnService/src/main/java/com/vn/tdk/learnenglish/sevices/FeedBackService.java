package com.vn.tdk.learnenglish.sevices;

import com.vn.tdk.learnenglish.entity.FeedBack;

public interface FeedBackService extends services<FeedBack> {

}
