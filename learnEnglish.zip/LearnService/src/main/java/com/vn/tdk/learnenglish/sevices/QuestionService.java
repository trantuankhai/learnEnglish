package com.vn.tdk.learnenglish.sevices;

import com.vn.tdk.learnenglish.entity.Question;

public interface QuestionService extends services<Question>{

}
