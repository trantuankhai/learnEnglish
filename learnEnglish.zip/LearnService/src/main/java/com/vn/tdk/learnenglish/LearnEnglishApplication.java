package com.vn.tdk.learnenglish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnEnglishApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnEnglishApplication.class, args);
	}

}
