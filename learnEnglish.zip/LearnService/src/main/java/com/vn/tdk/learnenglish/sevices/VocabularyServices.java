package com.vn.tdk.learnenglish.sevices;

import com.vn.tdk.learnenglish.entity.Vocabulary;

public interface VocabularyServices extends services<Vocabulary> {

}
