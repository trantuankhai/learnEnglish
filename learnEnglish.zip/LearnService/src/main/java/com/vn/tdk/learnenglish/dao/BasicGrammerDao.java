package com.vn.tdk.learnenglish.dao;

import com.vn.tdk.learnenglish.entity.BasicGrammar;

public interface BasicGrammerDao extends TempleteDao<BasicGrammar> {

}
