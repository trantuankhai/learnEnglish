package com.vn.tdk.learnenglish.common;

public enum Role {
	ADMIN,TEACHER,USER,
}
