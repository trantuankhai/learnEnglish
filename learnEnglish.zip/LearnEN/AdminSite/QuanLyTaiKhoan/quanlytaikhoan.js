adminSite.controller('acountManagerController',  function($http,$scope,$rootScope){
	$scope.checkAdd = false;
	$scope.checkEdit = false;
	$http.get($rootScope.link+"acount").then(function(res){
		$scope.listAcount = res.data;
		$scope.isActive =res.data.isActive;
	},function(error){
		console.log(error)
	});
$scope.activeAcount = function(acount){
	$scope.acount = $scope.acount;
	$http.get($rootScope.link+"acount/active/"+acount.id_account,{headers: {'Accept': 'text/plain'}}).then(function(res){
	var status = res.data;

		if(status == 'SUCCESS'){
		$http.get($rootScope.link+"acount").then(function(res){
		$scope.listAcount = res.data;
		$scope.isActive =res.data.isActive;
	},function(error){
		console.log(error)
	});
		}
		console.log(res.data);
	}, function(error){

	})
}
$scope.noneActiveAcount = function(acount){
	$http.get($rootScope.link+"acount/noneActive/"+acount.id_account,{headers: {'Accept': 'text/plain'}}).then(function(res){
	var status = res.data;

		if(status == 'SUCCESS'){
		$http.get($rootScope.link+"acount").then(function(res){
		$scope.listAcount = res.data;
		$scope.isActive =res.data.isActive;
	},function(error){
		console.log(error);
	});
		}
	}, function(error){

	})
}
$scope.showAdd = function(){
		$scope.checkAdd = true;
		$scope.checkEdit = false;
		//clearFrom();
		//$('#nameDeparts').focus();
}
$scope.showEdit = function(){
		$scope.checkAdd = false;
		$scope.checkEdit = true;
		//clearFrom();
		//$('#nameDeparts').focus();
}
$scope.removeAcount = function(id_account,index){
	var result  = confirm('Bạn có muốn xóa không?')
	if(result == true)
	{
		$http.delete($rootScope.link+"acount?id="+id_account,{headers: {'Accept': 'text/plain'}}).then(function(res){
			if(res.data == 'SUCCESS'){
			$scope.listAcount.splice(index,1);
			}

		}, function(error){
			console.log(error);	
		});	
	}
}
$scope.addAcount = function(){
	$scope.tempAcount.role = 'USER';
	console.log('oke')
	var linkAdd = $rootScope.link+"acount/register/admin?"+"email="+$scope.tempAcount.Email+"&fullName="+$scope.tempAcount.Name+"&passWord="+$scope.tempAcount.passWord+"&role="+$scope.tempAcount.role+"&userName="+$scope.tempAcount.userName;
	$http.post(linkAdd,{}).then(function(res){
		console.log(res.data);
					if(res.data == -1){
				swal({
					title: "Đăng ký thất bại!",
					text: "Vui lòng liên hệ với quản trị viên!",
					icon: "error",
					button: "Xác nhận!",
				});
			}else if(res.data == -2){
					swal({
					title: "Tài khoản đã tồn tại!",
					text: "Mời bạn nhập tài khoản khác!",
					icon: "warning",
					button: "Xác nhận!",
				});
			// $scope.email= null;
			// $scope.fullName = null;
			// $scope.passWord = null ;
			// $scope.userName = null;
				
			}else{
				$http.get($rootScope.link+"acount").then(function(res){
					$scope.listAcount = res.data;
				},function(error){
					console.log(error)
				});
			}
	}, function(error){
		console.log(error);

	})

}
	
});