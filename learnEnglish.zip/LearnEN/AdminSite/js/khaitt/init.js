var adminSite = angular.module('adminApp', ['ngRoute']);
adminSite.run( function($rootScope,$window,$http,$interval){
	$rootScope.link = "http://localhost:8010/";
// 	var token = $window.localStorage.getItem('token');
// 	if(token!=null)
// 	{
// 		$http.defaults.headers.common['Authorization'] = 'Bearer ' +token;
// 		$http.get($rootScope.link+"acount/resolveToken").then(function(res){
// 		var role = res.data.role;
// 			if(role == 'USER'){
// 				alert('Bạn không đủ quyền vào trang.');
// 				$window.location.href = "../Login";
// 			}

// 		},function(error){
// 			$window.localStorage.removeItem('token');
// 			$window.location.href = "../Login";
// 		})
// 	}else
// 	{
// 		$window.location.href = "../Login";
// 	}
// function checkTimeOut(){
// 	$http.get($rootScope.link+"acount/resolveToken").then(function(res){

// 	},function(error){
// 		$window.localStorage.removeItem('token');
// 		$window.location.href = "../Login";
// 	});
// }
//  var checkSession = setInterval(checkTimeOut,60000);
});
adminSite.config(function($routeProvider) {
	$routeProvider.when("/", {
		controller : 'dashBoardController',
   		templateUrl : 'Dashboard/_dashboard.html'
	})
	.when("/quan-ly-tai-khoan", {
		controller : 'acountManagerController',
   		templateUrl : 'QuanLyTaiKhoan/_quanlytaikhoan.html'
	})
	.when("/quan-ly-chu-de", {
		controller : 'themeManagerController',
   		templateUrl : 'QuanLyChuDe/_quanlychude.html'
	})
	.otherwise({
	 	templateUrl : 'Dashboard/_dashboard.html'
	 });

});