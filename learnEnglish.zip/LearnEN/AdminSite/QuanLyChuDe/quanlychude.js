adminSite.controller('themeManagerController', function($http,$scope,$rootScope){
	$http.get($rootScope.link+"theme").then(function(res){
		$scope.listTheme = res.data;
	}, function(error){
		console.log(error);
	});
});